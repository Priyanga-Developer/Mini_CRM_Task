import { useState, useCallback, useEffect } from 'react';
import type { Lead, LeadStatus, KPIData } from '@/types/lead';
import { leadsService } from '@/services/leads';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { KPICards } from '@/components/dashboard/KPICards';
import { LeadTable } from '@/components/dashboard/LeadTable';
import { LeadDrawer } from '@/components/dashboard/LeadDrawer';
import { CreateLeadModal } from '@/components/dashboard/CreateLeadModal';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Dashboard() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [kpiData, setKpiData] = useState<KPIData>({
    totalLeads: 0,
    newLeads: 0,
    qualifiedLeads: 0,
    lostLeads: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [updatingLeadId, setUpdatingLeadId] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchLeads = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await leadsService.getLeads();
      setLeads(data);
      setKpiData(leadsService.getKPIData(data));
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load leads',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchLeads();
  }, [fetchLeads]);

  const handleRowClick = useCallback((lead: Lead) => {
    setSelectedLead(lead);
    setIsDrawerOpen(true);
  }, []);

  const handleDrawerClose = useCallback(() => {
    setIsDrawerOpen(false);
    // Keep selectedLead for a moment to prevent drawer content flash
    setTimeout(() => setSelectedLead(null), 300);
  }, []);

  const handleStatusChange = useCallback(
    async (leadId: string, newStatus: LeadStatus) => {
      const originalLeads = [...leads];
      const originalKpi = { ...kpiData };

      // Optimistic update
      const updatedLeads = leads.map((lead) =>
        lead.id === leadId ? { ...lead, status: newStatus } : lead
      );
      setLeads(updatedLeads);
      setKpiData(leadsService.getKPIData(updatedLeads));

      // Update selected lead if it's the one being changed
      if (selectedLead?.id === leadId) {
        setSelectedLead({ ...selectedLead, status: newStatus });
      }

      setUpdatingLeadId(leadId);

      try {
        await leadsService.updateLeadStatus(leadId, newStatus);
        toast({
          title: 'Status updated',
          description: `Lead status changed to ${newStatus}`,
        });
      } catch (error) {
        // Rollback on failure
        setLeads(originalLeads);
        setKpiData(originalKpi);

        if (selectedLead?.id === leadId) {
          const originalLead = originalLeads.find((l) => l.id === leadId);
          if (originalLead) setSelectedLead(originalLead);
        }

        toast({
          title: 'Update failed',
          description: error instanceof Error ? error.message : 'Failed to update status',
          variant: 'destructive',
        });
      } finally {
        setUpdatingLeadId(null);
      }
    },
    [leads, kpiData, selectedLead, toast]
  );

  const handleLeadCreated = useCallback(() => {
    fetchLeads();
  }, [fetchLeads]);

  return (
    <DashboardLayout>
      <div className="p-4 pt-16 lg:p-8 lg:pt-8">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
            <p className="text-sm text-muted-foreground">
              Manage and track your leads effectively
            </p>
          </div>
          <Button onClick={() => setIsCreateModalOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Lead
          </Button>
        </div>

        {/* KPI Cards */}
        <div className="mb-8">
          <KPICards data={kpiData} isLoading={isLoading} />
        </div>

        {/* Lead Table */}
        <div>
          <h2 className="mb-4 text-lg font-semibold">All Leads</h2>
          <LeadTable
            leads={leads}
            isLoading={isLoading}
            onRowClick={handleRowClick}
            onStatusChange={handleStatusChange}
            updatingLeadId={updatingLeadId}
          />
        </div>
      </div>

      {/* Lead Drawer */}
      <LeadDrawer
        lead={selectedLead}
        isOpen={isDrawerOpen}
        onClose={handleDrawerClose}
        onStatusChange={handleStatusChange}
        isUpdating={updatingLeadId === selectedLead?.id}
      />

      {/* Create Lead Modal */}
      <CreateLeadModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSuccess={handleLeadCreated}
      />
    </DashboardLayout>
  );
}
