import type {  LeadStatus } from '@/types/lead';
import type { StatusSelectCellProps } from '@/types/dashboard';
import { StatusBadge } from './StatusBadge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

export function StatusSelectCell({
  lead,
  isUpdating,
  onStatusChange,
}: StatusSelectCellProps) {
  const handleStatusSelect = (value: string) => {
    onStatusChange(
      { stopPropagation: () => {} } as React.MouseEvent,
      lead.id,
      value as LeadStatus
    );
  };

  return (
    <div className="relative" onClick={(e) => e.stopPropagation()}>
      {isUpdating ? (
        <div className="flex items-center gap-2">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm text-muted-foreground">Updating...</span>
        </div>
      ) : (
        <Select value={lead.status} onValueChange={handleStatusSelect}>
          <SelectTrigger className="w-[130px] h-8">
            <SelectValue asChild>
              <StatusBadge status={lead.status} />
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="new">
              <StatusBadge status="new" />
            </SelectItem>
            <SelectItem value="contacted">
              <StatusBadge status="contacted" />
            </SelectItem>
            <SelectItem value="qualified">
              <StatusBadge status="qualified" />
            </SelectItem>
            <SelectItem value="lost">
              <StatusBadge status="lost" />
            </SelectItem>
          </SelectContent>
        </Select>
      )}
    </div>
  );
}
